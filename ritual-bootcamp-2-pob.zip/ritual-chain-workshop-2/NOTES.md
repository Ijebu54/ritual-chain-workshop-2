# Bootcamp 2 notes

Fork the official workshop, keep the name `ritual-chain-workshop-2`, push your own commits, then paste the public GitHub URL into the academy portal before **2 September 2026, 16:00**.

What the five stubs had to do:

1. `createMarket` — store the rule, convert seconds → blocks, call the Scheduler.
2. `_scheduleResolution` — `numCalls = 3`, `frequency = 200` blocks, first arg of callback is `executionIndex`.
3. `_pickExecutor` — registry + unique seed per attempt so one bad TEE cannot sink the market.
4. `_readOracle` — HTTP 0x0801 then jq 0x0803; wrap decode in `try` so bad bytes increment the attempt counter.
5. `onScheduledResolve` — only the Scheduler; never revert on oracle failure; cancel leftover executions after success.

Common trap: the repo ships `test/Counter.ts` from the Hardhat template. Delete it or tests fail with `Artifact for contract "Counter" not found`.
