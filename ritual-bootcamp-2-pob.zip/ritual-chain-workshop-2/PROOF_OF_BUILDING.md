# Proof of Building — Ritual Academy Bootcamp 2

Self-Resolving Prediction Market on Ritual Chain.

**Upstream:** https://github.com/cozfuttu/ritual-chain-workshop-2  
**Keep the repo name:** `ritual-chain-workshop-2` and make the fork public.

## What I shipped

The starter left five Ritual-specific bodies as `// we'll fill this up`. Those are implemented:

| Function | What it does |
|---|---|
| `createMarket` | Validates inputs, converts human seconds → block numbers with `blockTimeMs`, stores the immutable resolution rule, books `MAX_ATTEMPTS` Scheduler calls |
| `_scheduleResolution` | Encodes `onScheduledResolve(0, marketId)` so the Scheduler can overwrite `executionIndex` |
| `_pickExecutor` | Asks `TEEServiceRegistry.pickServiceByCapability(HTTP_CALL, …)` with a per-attempt seed |
| `_readOracle` | HTTP precompile GET → unwrap async envelope via `try decodeHttpResponse` → jq uint256. Failures are **not** treated as NO |
| `onScheduledResolve` | Scheduler-only, revert-free for oracle problems, retries 3×, empty winning side → Invalid, then `cancel()` leftover calls |

Small original extensions used by a UI / local demo:

- `quoteWindows` — preview close/resolve blocks
- `previewCompare` — explain the comparator without writing state
- `impliedYesBps` — pari-mutuel implied probability

Leftover Hardhat starter `test/Counter.ts` is removed (it deployed a contract that does not exist).

## How to run locally (testnet can be down)

```bash
cd hardhat
pnpm install          # or npm install
npx hardhat test      # Solidity tests against etched mocks
npx hardhat build
```

No funded wallet and no live RPC are required for tests. Mocks are etched onto the canonical Ritual addresses in `RitualChain.sol`.

## Lifecycle covered by tests

1. Deploy with a valid `blockTimeMs`; reject `0`
2. Create market + schedule
3. Bet YES/NO while Open; reject after `closeBlock`
4. Scheduler callback resolves YES when observed ≥ target
5. Winner pulls `stake * totalPool / winningPool`
6. HTTP failure × 3 → Invalid → refund
7. Empty winning side → Invalid

## Notes

- Deadlines are **block numbers**, never `block.timestamp` (Ritual timestamps are milliseconds).
- A failed oracle read is never a NO.
- Payouts are pull-based and loop-free.
- Ritual public RPC may be offline; local Hardhat + mocks is the accepted path.

Workshop session: Ritual Academy Bootcamp 2 — Self-Resolving Prediction Market.
