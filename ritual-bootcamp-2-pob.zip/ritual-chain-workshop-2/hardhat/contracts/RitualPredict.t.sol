// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";
import {RitualPredict} from "./RitualPredict.sol";
import {RitualChain} from "./ritual/RitualChain.sol";
import {MockScheduler, MockRitualWallet, MockTEERegistry, MockHTTP, MockJQ} from "./mocks/RitualMocks.sol";

contract RitualPredictTest is Test {
    RitualPredict internal predict;
    MockScheduler internal scheduler;
    MockTEERegistry internal registry;
    MockHTTP internal http;
    MockJQ internal jq;

    address internal alice = address(0xA11CE);
    address internal bob = address(0xB0B);

    function setUp() public {
        scheduler = new MockScheduler();
        vm.etch(RitualChain.SCHEDULER, address(scheduler).code);
        vm.store(RitualChain.SCHEDULER, bytes32(uint256(0)), bytes32(uint256(1)));

        MockRitualWallet wallet = new MockRitualWallet();
        vm.etch(RitualChain.RITUAL_WALLET, address(wallet).code);

        registry = new MockTEERegistry();
        vm.etch(RitualChain.TEE_SERVICE_REGISTRY, address(registry).code);

        http = new MockHTTP();
        vm.etch(RitualChain.HTTP_PRECOMPILE, address(http).code);

        jq = new MockJQ();
        vm.etch(RitualChain.JQ_PRECOMPILE, address(jq).code);
        jq.set(4500, false);

        predict = new RitualPredict(195);

        vm.deal(alice, 100 ether);
        vm.deal(bob, 100 ether);
        vm.deal(address(this), 100 ether);
    }

    function _params() internal pure returns (RitualPredict.NewMarket memory) {
        return
            RitualPredict.NewMarket({
                question: "Will ETH/USD be at least $4000?",
                oracleUrl: "https://example.com/price.json",
                jsonPath: ".price",
                target: 4000,
                comparator: RitualPredict.Comparator.GTE,
                bettingSeconds: 60,
                resolveDelaySeconds: 30
            });
    }

    function test_constructorStoresBlockTime() public view {
        assertEq(predict.blockTimeMs(), 195);
    }

    function test_constructorRevertsOnZeroBlockTime() public {
        vm.expectRevert(RitualPredict.BadDuration.selector);
        new RitualPredict(0);
    }

    function test_createMarketStoresRuleAndSchedules() public {
        uint256 id = predict.createMarket(_params());
        RitualPredict.Market memory m = predict.getMarket(id);
        assertEq(id, 1);
        assertEq(m.creator, address(this));
        assertEq(m.target, 4000);
        assertEq(uint256(m.comparator), uint256(RitualPredict.Comparator.GTE));
        assertEq(uint256(m.state), uint256(RitualPredict.MarketState.Open));
        assertGt(m.scheduleId, 0);
        assertGt(m.closeBlock, block.number);
        assertGt(m.resolveBlock, m.closeBlock);
    }

    function test_createMarketRevertsOnEmptyQuestion() public {
        RitualPredict.NewMarket memory p = _params();
        p.question = "";
        vm.expectRevert(RitualPredict.EmptyString.selector);
        predict.createMarket(p);
    }

    function test_createMarketRevertsOnBadDuration() public {
        RitualPredict.NewMarket memory p = _params();
        p.bettingSeconds = 1;
        vm.expectRevert(RitualPredict.BadDuration.selector);
        predict.createMarket(p);
    }

    function test_betRecordsPools() public {
        uint256 id = predict.createMarket(_params());
        vm.prank(alice);
        predict.bet{value: 2 ether}(id, true);
        vm.prank(bob);
        predict.bet{value: 1 ether}(id, false);

        RitualPredict.Market memory m = predict.getMarket(id);
        assertEq(m.totalYes, 2 ether);
        assertEq(m.totalNo, 1 ether);
        assertEq(predict.impliedYesBps(id), 6666);
    }

    function test_betRevertsAfterClose() public {
        uint256 id = predict.createMarket(_params());
        RitualPredict.Market memory m = predict.getMarket(id);
        vm.roll(m.closeBlock);
        vm.prank(alice);
        vm.expectRevert(RitualPredict.BettingClosed.selector);
        predict.bet{value: 1 ether}(id, true);
    }

    function test_betRevertsOnZeroStake() public {
        uint256 id = predict.createMarket(_params());
        vm.expectRevert(RitualPredict.ZeroStake.selector);
        predict.bet{value: 0}(id, true);
    }

    function test_onlySchedulerCanResolve() public {
        uint256 id = predict.createMarket(_params());
        vm.expectRevert(RitualPredict.OnlyScheduler.selector);
        predict.onScheduledResolve(0, id);
    }

    function test_successfulResolvePaysWinner() public {
        uint256 id = predict.createMarket(_params());
        vm.prank(alice);
        predict.bet{value: 2 ether}(id, true);
        vm.prank(bob);
        predict.bet{value: 1 ether}(id, false);

        RitualPredict.Market memory m = predict.getMarket(id);
        vm.roll(m.resolveBlock);

        MockScheduler live = MockScheduler(payable(RitualChain.SCHEDULER));
        live.execute(
            address(predict),
            abi.encodeWithSelector(predict.onScheduledResolve.selector, uint256(0), id)
        );

        m = predict.getMarket(id);
        assertEq(uint256(m.state), uint256(RitualPredict.MarketState.Resolved));
        assertEq(uint256(m.outcome), uint256(RitualPredict.Outcome.Yes));
        assertEq(m.observedValue, 4500);

        uint256 before = alice.balance;
        vm.prank(alice);
        predict.claimWinnings(id);
        assertEq(alice.balance, before + 3 ether);

        vm.prank(bob);
        vm.expectRevert(RitualPredict.NothingToClaim.selector);
        predict.claimWinnings(id);
    }

    function test_oracleFailureThreeTimesInvalidatesAndRefunds() public {
        http.setFail(true);
        uint256 id = predict.createMarket(_params());
        vm.prank(alice);
        predict.bet{value: 1 ether}(id, true);

        RitualPredict.Market memory m = predict.getMarket(id);
        vm.roll(m.resolveBlock);
        MockScheduler live = MockScheduler(payable(RitualChain.SCHEDULER));

        for (uint256 i = 0; i < 3; i++) {
            live.execute(
                address(predict),
                abi.encodeWithSelector(predict.onScheduledResolve.selector, i, id)
            );
        }

        m = predict.getMarket(id);
        assertEq(uint256(m.state), uint256(RitualPredict.MarketState.Invalid));

        uint256 before = alice.balance;
        vm.prank(alice);
        predict.claimRefund(id);
        assertEq(alice.balance, before + 1 ether);
    }

    function test_emptyWinningSideBecomesInvalid() public {
        jq.set(1000, false); // observed 1000 < 4000 → NO
        uint256 id = predict.createMarket(_params());
        vm.prank(alice);
        predict.bet{value: 1 ether}(id, true); // only YES staked

        RitualPredict.Market memory m = predict.getMarket(id);
        vm.roll(m.resolveBlock);
        MockScheduler live = MockScheduler(payable(RitualChain.SCHEDULER));
        live.execute(
            address(predict),
            abi.encodeWithSelector(predict.onScheduledResolve.selector, uint256(0), id)
        );

        m = predict.getMarket(id);
        assertEq(uint256(m.state), uint256(RitualPredict.MarketState.Invalid));
    }

    function test_previewCompareAndQuoteWindows() public view {
        assertTrue(predict.previewCompare(4000, 4000, RitualPredict.Comparator.GTE));
        assertFalse(predict.previewCompare(3999, 4000, RitualPredict.Comparator.GTE));
        (uint64 closeB, uint64 resolveB) = predict.quoteWindows(60, 30);
        assertGt(resolveB, closeB);
    }

    function test_unknownMarketReverts() public {
        vm.expectRevert(RitualPredict.UnknownMarket.selector);
        predict.getMarket(99);
    }

    function test_fundExecution() public {
        predict.fundExecution{value: 0.5 ether}(100);
        assertEq(predict.executionBalance(), 0.5 ether);
    }
}
