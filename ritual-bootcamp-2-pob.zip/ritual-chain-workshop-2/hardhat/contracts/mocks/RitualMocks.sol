// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

/// Test-only stand-ins etched onto the canonical Ritual addresses.

contract MockScheduler {
    uint256 public nextCallId = 1;
    mapping(address => bool) public approved;
    mapping(uint256 => bytes) public callData;
    mapping(uint256 => bool) public cancelled;

    function approveScheduler(address) external {
        approved[msg.sender] = true;
    }

    function schedule(
        bytes calldata data,
        uint32,
        uint32,
        uint32,
        uint32,
        uint32,
        uint256,
        uint256,
        uint256,
        address
    ) external returns (uint256 callId) {
        callId = nextCallId++;
        callData[callId] = data;
    }

    function cancel(uint256 callId) external {
        cancelled[callId] = true;
    }

    function getCallState(uint256 callId) external view returns (uint8) {
        return cancelled[callId] ? 2 : 1;
    }

    /// Test helper: act as the Scheduler and invoke a target callback.
    function execute(address target, bytes calldata data) external {
        (bool ok, bytes memory ret) = target.call(data);
        if (!ok) {
            assembly {
                revert(add(ret, 32), mload(ret))
            }
        }
    }
}

contract MockRitualWallet {
    mapping(address => uint256) public balanceOf;
    mapping(address => uint256) public lockUntil;

    function deposit(uint256 lockDuration) external payable {
        balanceOf[msg.sender] += msg.value;
        lockUntil[msg.sender] = block.number + lockDuration;
    }
}

contract MockTEERegistry {
    address public tee;
    bool public found = true;

    constructor() {
        tee = address(0x7EE);
    }

    function set(address tee_, bool found_) external {
        tee = tee_;
        found = found_;
    }

    function pickServiceByCapability(
        uint8,
        bool,
        uint256,
        uint256
    ) external view returns (address, bool) {
        return (tee, found);
    }
}

contract MockHTTP {
    uint16 public status = 200;
    bytes public body = '{"price":4500}';
    string public err = "";
    bool public shouldFail;

    function setResponse(uint16 status_, bytes memory body_, string memory err_) external {
        status = status_;
        body = body_;
        err = err_;
        shouldFail = false;
    }

    function setFail(bool v) external {
        shouldFail = v;
    }

    fallback() external payable {
        if (shouldFail) revert("http down");
        bytes memory actual = abi.encode(status, new string[](0), new string[](0), body, err);
        bytes memory envelope = abi.encode(bytes(""), actual);
        assembly {
            return(add(envelope, 32), mload(envelope))
        }
    }
}

contract MockJQ {
    bool public shouldFail;
    uint256 public forced;

    function set(uint256 value, bool fail) external {
        forced = value;
        shouldFail = fail;
    }

    fallback() external view {
        if (shouldFail) {
            assembly {
                revert(0, 0)
            }
        }
        uint256 v = forced;
        assembly {
            mstore(0x00, v)
            return(0x00, 32)
        }
    }
}
